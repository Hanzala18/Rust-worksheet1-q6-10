use std::io;
fn sum(x:u32) ->u32{
if x ==0{
    return 1;
} 
x + sum(x-1)
}



fn main() {
    println!("Enter any number");
    let mut input=String::new();
    io::stdin().read_line(&mut input).expect("No only");
    let x: u32 = input.trim().parse().expect("failed");
    
    let add =sum(x);
    println!("sum of value from 1 to {} is {}",x,add);
}
