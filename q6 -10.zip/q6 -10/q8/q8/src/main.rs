use std::vec;

fn palindrone(value:&str) ->bool{
    let value = value.trim().to_lowercase();
    let chars: Vec<char> = value.chars().collect();

    let len= chars.len();
    for i in 0..len /2{
        if chars[i] !=chars[len - 1 -i]{
            return false;
        }
    }true
}

fn main() {
    let input1 = "level";
    if palindrone(input1){
        println!("{} its is palindrone",input1);
    }else {
        println!("{} not a palindrone",input1);
    }

}
