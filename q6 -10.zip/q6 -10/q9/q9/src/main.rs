use rand::Rng;//for random selection
use std::cmp::Ordering;//for comparing
use std::io;// for input

fn main() {
    println!("Guess the number!");
    
    let secret_number = rand::thread_rng().gen_range(1..=100);// to random guess no btw 1 to 100

    loop {
        println!("Please enter your guess:");

        let mut guess = String::new();

        io::stdin().read_line(&mut guess).expect("Failed ");

        let guess: u32 = match guess.trim().parse() {
            Ok(num) => num,
            Err(_) => {
                println!("Please enter correct number.");
                continue;
            }
        };

        match guess.cmp(&secret_number) {
            Ordering::Less => println!("Too low!"),
            Ordering::Greater => println!("Too high!"),
            Ordering::Equal => {
                println!("Congratulations, you guessed the number!");
                break;
            }
        }
    }
}
