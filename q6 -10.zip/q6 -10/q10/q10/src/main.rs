use std::io;

fn main() {
    println!(" Calculator");
    let num1: f64 = get_number("Enter the first number:");
    let operator: char = get_operator("Enter an operator (+, -, *, /):");
    let num2: f64 = get_number("Enter the second number:");
    let result = match operator {
        '+' => num1 + num2,
        '-' => num1 - num2,
        '*' => num1 * num2,
        '/' => {
            if num2 != 0.0 {
                num1 / num2
            } else {
                println!("Error: Division by zero.");
                return;
            }
        }
        _ => {
            println!("Invalid operator.");
            return;
        }
    };

    println!("Result: {} {} {} = {}", num1, operator, num2, result);
}

fn get_number(prompt: &str) -> f64 {
    loop {
        println!("{}", prompt);

        let mut input = String::new();
        io::stdin().read_line(&mut input).expect("Failed");

        match input.trim().parse() {
            Ok(num) => return num,
            Err(_) => {
                println!("Invalid input. Please enter a valid number.");
                continue;
            }
        }
    }
}

fn get_operator(prompt: &str) -> char {
    loop {
        println!("{}", prompt);

        let mut input = String::new();
        io::stdin().read_line(&mut input).expect("Failed");

        let operator = input.trim();
        if operator.len() == 1 && "+-*/".contains(operator) {
            return operator.chars().next().unwrap();
        }

        println!("Invalid operator. Please enter +, -, *, or /.");
    }
}
